package com.example.ch3_view

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ch3_view.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

//    lateinit var button: Button
//    lateinit var editView: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

//        //화면 출력, inflate, 뷰 객체 생성 완료..
//        setContentView(R.layout.activity_main)
//        //필요한 뷰 객체 획득..
//        button = findViewById(R.id.button)
//        editView = findViewById(R.id.editView)
//        //이벤트 추가..
//        button.setOnClickListener {
//            val data = editView.text.toString()
//            Log.d("kkang", data)
//        }

        //ViewBinding....
        //viewBinding 에 inflate 명령....
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //binding 에 변수 이름은 id 로...
        binding.button.setOnClickListener {
            val data = binding.editView.text.toString()
            Log.d("kkang", data)
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}