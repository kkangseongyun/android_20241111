package com.example.tripapp.db

import android.content.Context
import android.database.Cursor

fun insertInfo(context: Context, email: String, phone: String?, photo: String?): Boolean {
    try {
        val db = DBHelper(context).writableDatabase
        db.execSQL("insert into TB_INFO (email, phone, photo) values (?,?,?)",
            arrayOf(email, phone, photo)
        )
        db.close()
        return true
    }catch (e: Exception){
        e.printStackTrace()
        return false
    }
}
fun selectInfo(context: Context): Cursor? {
    try {
        val db = DBHelper(context).readableDatabase
        val cursor = db.rawQuery("select * from TB_INFO order by _id DESC limit 1",
            null)
        return cursor
    }catch (e: Exception){
        e.printStackTrace()
        return null
    }
}