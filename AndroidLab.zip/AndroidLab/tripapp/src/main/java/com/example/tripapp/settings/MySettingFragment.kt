package com.example.tripapp.settings

import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.example.tripapp.R

//설정 xml 을 등록하기 위한 클래스...
//이 클래스는 원론적으로 View(Fragment)이다.. Activity 가 출력해 주어야 한다..
class MySettingFragment: PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        //아래 코드 한줄로.. 화면, 저장 자동..
        setPreferencesFromResource(R.xml.settings, rootKey)
        //아래 코드는 필요하다면..
        //key 로 설정 객체 획득..
        val idPreference: EditTextPreference? = findPreference("id")
        val colorPreference: ListPreference? = findPreference("color")

        //유저가 설정한 값을 그대로 summary 에 출력하면 된다면..
        colorPreference?.summaryProvider = ListPreference.SimpleSummaryProvider.getInstance()

        //유저 설정 값을 참조해서.. 알고리즘으로 summary 를 출력한다면..
        idPreference?.summaryProvider =
            Preference.SummaryProvider<EditTextPreference> { preference ->
                //유저 설정 값 획득..
                val id = preference.text
                if(TextUtils.isEmpty(id)){
                    "설정이 되지 않았습니다."//리턴 시킨 문자열이 summary 에 찍힌다..
                }else {
                    "설정한 ID 는 $id 입니다."
                }
            }

        //변경 순간 저장은 자동으로 되지만.. 이벤트 처리에 의해 처리할 로직이 있다면..
        idPreference?.setOnPreferenceChangeListener { preference, newValue ->
            Log.d("kkang", "new value : $newValue")
            true
        }
    }
}