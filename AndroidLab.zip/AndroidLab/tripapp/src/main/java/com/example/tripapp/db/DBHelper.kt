package com.example.tripapp.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

//database 관리적인 코드 추상화..
class DBHelper(context: Context): SQLiteOpenHelper(context, "testdb", null, 1) {
    //app install 후 이 helper 가 이용되는 최초한번 호출..
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("create table TB_INFO (" +
                "_id integer primary key autoincrement," +
                "email not null," +
                "phone," +
                "photo)")
    }
    //db version 변경시마다..
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {

    }
}