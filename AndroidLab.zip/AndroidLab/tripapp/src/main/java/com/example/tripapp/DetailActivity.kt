package com.example.tripapp

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.example.tripapp.databinding.ActivityDetailBinding
import com.example.tripapp.detail.DetailMainFragment
import com.example.tripapp.detail.DetailNewsFragment

class DetailActivity : AppCompatActivity() {

    //viewpager 항목(화면)을 구성해 주는 어댑터..
    class MyPagerAdapter(activity: FragmentActivity): FragmentStateAdapter(activity){
        val fragments: List<Fragment>
        init {
            fragments = listOf(DetailMainFragment(), DetailNewsFragment())
        }
        //항목 갯수를 판단하기 위해 초기 한번 호출..
        override fun getItemCount(): Int {
            return fragments.size
        }
        //각 항목의 프래그먼트를 결정하기 위해서 반복 호출..
        override fun createFragment(position: Int): Fragment {
            return fragments[position]
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //viewpager 에 adapter 적용..
        val adapter = MyPagerAdapter(this)
        binding.viewpager.adapter = adapter
    }
}