package com.example.tripapp

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.View.OnClickListener
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tripapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    //back button 을 누른 순간의 시간..
    var initTime = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //object : 익명 클래스 선언 예약어..
        //이름을 가지는 클래스 선언은
        //class A : OnClickListener {}
        //익명 클래스는 object: OnClickListener {}
//        binding.mainEvent1.setOnClickListener(object : OnClickListener {
//            override fun onClick(v: View?) {
//
//            }
//        })

        //추상함수 하나를 가지는 인터페이스를 구현한 object 클래스를 선언할때..
        //추상함수 내용만 {} 로 축약해서 작성.. ==> Single Abstract Method 기법
//        binding.mainEvent1.setOnClickListener({
//            //onClick 함수의 내용 부분
//        })
        //함수의 매개변수가 함수라면.. 마지막 매개변수에 한해서 () 밖에 선언이 가능하다..
//        fun a(arg1: Int, arg2: (Int)->Int){}
//        a(10, {  10 })
//        a(10){10}
        binding.mainEvent1.setOnClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }

        binding.testGoAboutButton.setOnClickListener {
            val intent = Intent(this, AboutActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if(keyCode === KeyEvent.KEYCODE_BACK){
            if(System.currentTimeMillis() - initTime > 3000){
                Toast.makeText(this, "종료하려면 한번 더 누르세요.", Toast.LENGTH_SHORT)
                    .show()
                initTime = System.currentTimeMillis()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}