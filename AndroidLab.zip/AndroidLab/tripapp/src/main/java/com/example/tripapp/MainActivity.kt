package com.example.tripapp

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.View.OnClickListener
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tripapp.databinding.ActivityMainBinding
import com.example.tripapp.databinding.NavigationHeaderBinding
import com.example.tripapp.db.selectInfo

class MainActivity : AppCompatActivity() {

    //back button 을 누른 순간의 시간..
    var initTime = 0L

    lateinit var toggle: ActionBarDrawerToggle
    lateinit var headerBinding: NavigationHeaderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        headerBinding = NavigationHeaderBinding.bind(binding.mainDrawerView.getHeaderView(0))

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //Toolbar는 actionbar를 대체.. actionbar 의 내용이 toolbar 에 출력되게 설정..
        setSupportActionBar(binding.toolbar)

        //object : 익명 클래스 선언 예약어..
        //이름을 가지는 클래스 선언은
        //class A : OnClickListener {}
        //익명 클래스는 object: OnClickListener {}
//        binding.mainEvent1.setOnClickListener(object : OnClickListener {
//            override fun onClick(v: View?) {
//
//            }
//        })

        //추상함수 하나를 가지는 인터페이스를 구현한 object 클래스를 선언할때..
        //추상함수 내용만 {} 로 축약해서 작성.. ==> Single Abstract Method 기법
//        binding.mainEvent1.setOnClickListener({
//            //onClick 함수의 내용 부분
//        })
        //함수의 매개변수가 함수라면.. 마지막 매개변수에 한해서 () 밖에 선언이 가능하다..
//        fun a(arg1: Int, arg2: (Int)->Int){}
//        a(10, {  10 })
//        a(10){10}
        binding.mainEvent1.setOnClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }

//        binding.testGoAboutButton.setOnClickListener {
//
//        }
//
//        binding.testGoInfoButton.setOnClickListener {
//
//        }

//        binding.testGoSettingButton.setOnClickListener {
//            val intent = Intent(this, SettingActivity::class.java)
//            startActivity(intent)
//        }

        //drawer toggle...............................
        toggle = ActionBarDrawerToggle(this, binding.main, R.string.drawer_opened,
            R.string.drawer_closed)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toggle.syncState()//손으로 끄는 것과 토글 버튼이 싱크...

        //navigation view 항목 선택 이벤트.................
        binding.mainDrawerView.setNavigationItemSelectedListener {
            if(it.itemId == R.id.main_navigation_about){
                val intent = Intent(this, AboutActivity::class.java)
                startActivity(intent)
            }else if(it.itemId == R.id.main_navigation_edit_info){
                val intent = Intent(this, MyInfoActivity::class.java)
                startActivity(intent)
            }
            true
        }

        //db select 해서 정보를 drawer 에 출력..
        var cursor = selectInfo(this)
        cursor?.let {
            if(cursor.moveToFirst()){
                headerBinding.run {
                    userEmailView.setText(cursor.getString(1))
                }
            }
        }


    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if(keyCode === KeyEvent.KEYCODE_BACK){
            if(System.currentTimeMillis() - initTime > 3000){
                Toast.makeText(this, "종료하려면 한번 더 누르세요.", Toast.LENGTH_SHORT)
                    .show()
                initTime = System.currentTimeMillis()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        //ActionView(ActionBar 내장 view), 메뉴 기법으로 이용..
        //ActionView 가 연결된 menuitem 을 먼저 얻고.. 그곳에 연결된 view  획득..
        val menuItem = menu?.findItem(R.id.menu_search)
        val searchView = menuItem?.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String?): Boolean {
                //검색어 입력 순간마다..
                return true
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                //검색어 입력을 위해 올라온 키보드의 검색 버튼..
                Toast.makeText(this@MainActivity, query, Toast.LENGTH_SHORT)
                    .show()
                searchView.setQuery("", false)
                searchView.isIconified = true
                return true
            }
        })
        return super.onCreateOptionsMenu(menu)
    }

    //메뉴 이벤트 함수..
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        //toggle 버튼이 내부적으로 메뉴로 준비되어서.. return 시켜서.. 내부에 정의된 drawer 제어를 실행시키게..
        if(toggle.onOptionsItemSelected(item)){
            return true
        }
        else if(item.itemId == R.id.menu_setting){
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }
        return super.onOptionsItemSelected(item)
    }
}