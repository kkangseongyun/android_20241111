package com.example.tripapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tripapp.databinding.ActivityMyInfoBinding
import com.example.tripapp.db.insertInfo
import com.example.tripapp.db.selectInfo

class MyInfoActivity : AppCompatActivity() {

    lateinit var binding: ActivityMyInfoBinding

    var email: String? = null
    var phone: String? = null
    var photo: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMyInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        //db select 해서 화면 출력..
        val cursor = selectInfo(this)
        cursor?.let { //not null 이면..
            if(cursor.moveToFirst()){//row 를 선택
                //선택된 row 의 column data 추출해서 화면 출력..
                binding.run {
                    email = cursor.getString(1)
                    phone = cursor.getString(2)
                    photo = cursor.getString(3)

                    myInfoEmail.setText(email)
                    myInfoPhone.setText(phone)
                }
            }
        }

        binding.testSaveButton.setOnClickListener {
            //유저 입력 데이터 추출..
            binding.run {
                email = myInfoEmail.text.toString()
                phone = myInfoPhone.text.toString()
            }
            if(email?.isNotEmpty() ?: false){
                //email 이 입력되었다면..
                if(insertInfo(this, email ?: "", phone, photo)){
                    //화면을 자동으로 MainActivity(이전 화면) 로 전환
                    //데이터 넘겨서..
                    intent.putExtra("phone", phone)
                    intent.putExtra("email", email)
                    intent.putExtra("photo", photo)
                    setResult(RESULT_OK, intent)//상태 정보, 업무처리 잘 해서 되돌리는 거야...
                    //자신을 종료 시켜서.. 시스템에 의해 자동으로 이전화면으로 되돌아 가게..
                    finish()
                }
            }else {
                Toast.makeText(this, "email 은 필수 입력입니다.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
    }
}