package com.example.tripapp

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.content.PackageManagerCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.tripapp.databinding.ActivityMyInfoBinding
import com.example.tripapp.db.insertInfo
import com.example.tripapp.db.selectInfo
import java.io.*
import java.text.SimpleDateFormat
import java.util.Date

class MyInfoActivity : AppCompatActivity() {

    lateinit var binding: ActivityMyInfoBinding

    var email: String? = null
    var phone: String? = null
    var photo: String? = null

    lateinit var filePath: String//외장 앱별, 카메라 앱에게 공개하는 파일 경로..

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMyInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setSupportActionBar(binding.toolbar)

        //db select 해서 화면 출력..
        val cursor = selectInfo(this)
        cursor?.let { //not null 이면..
            if(cursor.moveToFirst()){//row 를 선택
                //선택된 row 의 column data 추출해서 화면 출력..
                binding.run {
                    email = cursor.getString(1)
                    phone = cursor.getString(2)
                    photo = cursor.getString(3)

                    myInfoEmail.setText(email)
                    myInfoPhone.setText(phone)
                }
            }
        }

//        binding.testSaveButton.setOnClickListener {
//
//        }
        binding.myInfoInternalButton.setOnClickListener {
            //내장 메모리에 파일 write...
            val file = File(filesDir, "test.txt")
            val writeStream = file.writer()
            writeStream.write("hello world - internal")
            writeStream.flush()

            //read....
            val readStream = file.reader().buffered()
            readStream.forEachLine {
                binding.myInfoInternalResult.text = it
            }
        }
        binding.myInfoExternalButton.setOnClickListener {
            //내장 메모리에 파일 write...
            val file = File(getExternalFilesDir(null), "test.txt")
            val writeStream = file.writer()
            writeStream.write("hello world - external")
            writeStream.flush()

            //read....
            val readStream = file.reader().buffered()
            readStream.forEachLine {
                binding.myInfoExternalResult.text = it
            }
        }

        //gallery app 연동..........................
        val galleryLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ){
            val uri = it.data!!.data!!//선택한 결과.. url 형식.. 마지막 단어가 선택한 사진 식별자..
            //이 url 을 이용해서 gallery app 에게 구체적으로 원하는 데이터 획득..
            val cursor = contentResolver.query(
                uri,
                arrayOf(MediaStore.Images.Media.DATA),//파일 경로..
                null, null, null
            )
            cursor?.let {
                if(cursor.moveToFirst()){
                    photo = cursor.getString(0)

                    val option = BitmapFactory.Options()
                    option.inSampleSize = 10//줄여서 로딩..
                    //갤러리 앱에서 사진을 읽을 수 있는 stream 제공..
                    val stream = contentResolver.openInputStream(uri)
                    val bitmap = BitmapFactory.decodeStream(stream, null, option)
                    binding.userImageView.setImageBitmap(bitmap)
                }
            }
        }

        //gallery app 연동 사진을 읽는 기능은 퍼미션이 요구된다.. 퍼미션 launcher
        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ){
            if(it){
                //퍼미션이 허락되었다면..
                //갤러리앱 목록 화면 실행..
                val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                intent.type = "image/*"
                galleryLauncher.launch(intent)
            }
        }

        binding.galleryButton.setOnClickListener {
            //퍼미션 체크.. 버전에 따라 다르게..
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU){
                if(ContextCompat.checkSelfPermission(
                        this, "android.permission.READ_MEDIA_IMAGES")
                    == PackageManager.GET_RECEIVERS){
                    val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                    intent.type = "image/*"
                    galleryLauncher.launch(intent)
                }else {
                    permissionLauncher.launch("android.permission.READ_MEDIA_IMAGES")
                }
            }else {
                if(ContextCompat.checkSelfPermission(
                        this, "android.permission.READ_EXTERNAL_STORAGE")
                    == PackageManager.GET_RECEIVERS){
                    val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                    intent.type = "image/*"
                    galleryLauncher.launch(intent)
                }else {
                    permissionLauncher.launch("android.permission.READ_EXTERNAL_STORAGE")
                }
            }
        }

        val cameraLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ){
            val option = BitmapFactory.Options()
            option.inSampleSize = 10
            val bitmap = BitmapFactory.decodeFile(filePath, option)
            binding.userImageView.setImageBitmap(bitmap)
        }

        binding.cameraButton.setOnClickListener {
            //파일 준비..
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            //외장 앱별에.. 이미지 저장되는 위치..
            val dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)

            val file = File.createTempFile(
                "JPEG_${stamp}_",
                ".jpg",
                dir
            )
            //나중에 읽어들일때 사용하기 위해서 파일 경로 저장..
            filePath = file.absolutePath
            //카메라앱에게 전달할 파일 정보.. Uri 로..
            val uri = FileProvider.getUriForFile(
                this,
                "com.example.tripapp.fileprovider",
                file
            )
            //intent 로 카메라 앱 실행..
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, uri)
            cameraLauncher.launch(intent)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.my_info_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == R.id.menu_my_info_save){
            //유저 입력 데이터 추출..
            binding.run {
                email = myInfoEmail.text.toString()
                phone = myInfoPhone.text.toString()
            }
            if(email?.isNotEmpty() ?: false){
                //email 이 입력되었다면..
                if(insertInfo(this, email ?: "", phone, photo)){
                    //화면을 자동으로 MainActivity(이전 화면) 로 전환
                    //데이터 넘겨서..
                    intent.putExtra("phone", phone)
                    intent.putExtra("email", email)
                    intent.putExtra("photo", photo)
                    setResult(RESULT_OK, intent)//상태 정보, 업무처리 잘 해서 되돌리는 거야...
                    //자신을 종료 시켜서.. 시스템에 의해 자동으로 이전화면으로 되돌아 가게..
                    finish()
                }
            }else {
                Toast.makeText(this, "email 은 필수 입력입니다.", Toast.LENGTH_SHORT)
                    .show()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}