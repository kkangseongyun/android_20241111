package com.example.tripapp.detail

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.tripapp.databinding.FragmentDetailMainBinding

class DetailMainFragment: Fragment() {
    //fragment 화면 준비..
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return FragmentDetailMainBinding.inflate(inflater, container, false).root
    }
}