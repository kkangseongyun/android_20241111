package com.example.tripapp.detail

import android.content.Context
import android.graphics.Rect
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.tripapp.R
import com.example.tripapp.databinding.FragmentDetailMainBinding
import com.example.tripapp.databinding.ItemRecyclerviewBinding

//항목 구성 view 객체를 가지는 역할..
class MyHolder(val binding: ItemRecyclerviewBinding): RecyclerView.ViewHolder(binding.root)

//상품 정보 추상화 VO
class Product(val photo: Int, val title: String, val desc: String)

//항목을 구성해주는 역할..
class MyAdapter(val datas: MutableList<Product>): RecyclerView.Adapter<MyHolder>() {
    //항목 갯수를 판단하기 위해서 자동 호출..
    override fun getItemCount(): Int {
        return datas.size
    }
    //항목 구성 view 객체를 가지는 holder 준비를 위해 자동 호출..
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyHolder {
        return MyHolder(ItemRecyclerviewBinding.inflate(LayoutInflater.from(
            parent.context
        ), parent, false))
    }
    //각각의 항목을 구성하기 위해서 자동 호출..
    override fun onBindViewHolder(holder: MyHolder, position: Int) {
        //항목 데이터 획득..
        val product = datas.get(position)
        //데이터 화면 출력..
        holder.binding.run {
            itemTitleView.text = product.title
            itemDescView.text = product.desc
            itemImageView.setImageResource(product.photo)
        }
    }
}

//꾸미기 작업..
class MyDecoration(val context: Context): RecyclerView.ItemDecoration(){
    //각각의 항목 꾸미기 작업.. 매개변수에 각 항목이 출력되는 사각형 정보가 전달..
    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)
        //몇번째 항목을 꾸미기 위해서 호출된 것인지 획득..
        val index = parent.getChildAdapterPosition(view) + 1
        if(index % 3 == 0)
            outRect.set(10, 10, 10, 60)
        else
            outRect.set(10, 10, 10, 0)
    }
}

//항목 구성 데이터...
val datas = mutableListOf<Product>(
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
)

class DetailMainFragment: Fragment() {
    //fragment 화면 준비..
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding =  FragmentDetailMainBinding.inflate(inflater, container, false)

        //recyclerview 에 구성요소 적용..
        binding.recyclerView.layoutManager = LinearLayoutManager(activity)
        binding.recyclerView.adapter = MyAdapter(datas)
        binding.recyclerView.addItemDecoration(MyDecoration(activity as Context))

        return binding.root
    }
}