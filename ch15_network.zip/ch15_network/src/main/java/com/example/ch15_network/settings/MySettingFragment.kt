package com.example.ch15_network.settings

import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import androidx.preference.EditTextPreference
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.example.ch15_network.R


class MySettingFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.settings, rootKey)

        val idPreference: EditTextPreference? = findPreference("id")
        val colorPreference: ListPreference? = findPreference("color")

//        idPreference?.summaryProvider = EditTextPreference.SimpleSummaryProvider.getInstance()
        colorPreference?.summaryProvider = ListPreference.SimpleSummaryProvider.getInstance()

        idPreference?.summaryProvider =
            Preference.SummaryProvider<EditTextPreference> { preference ->
                val text = preference.text
                if (TextUtils.isEmpty(text)) {
                    "설정이 되지 않았습니다. "
                } else {
                    "설정된 ID 값은 : $text 입니다."
                }
            }

        idPreference?.setOnPreferenceChangeListener { preference, newValue ->
            Log.d("kkang", "preference key : ${preference.key}, newValue : $newValue")
            true
        }

    }
}