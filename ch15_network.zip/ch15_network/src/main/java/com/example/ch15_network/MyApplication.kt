package com.example.ch15_network

import android.app.Application
import com.example.ch15_network.network.NetworkService
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MyApplication: Application(){
    companion object {
        //복사해서 작성
        val API_KEY = "079dac74a5f94ebdb990ecf61c8854b7"
        val BASE_URL = "https://newsapi.org"


        //add....................................
        val retrofit: Retrofit
            get() = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        val networkService = retrofit.create(NetworkService::class.java)
    }
}