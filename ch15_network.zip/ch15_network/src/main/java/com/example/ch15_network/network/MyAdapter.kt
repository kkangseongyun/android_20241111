package com.example.sol.network

import android.content.Context
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.ch15_network.MyApplication
import com.example.ch15_network.databinding.ItemNewsBinding
import com.example.ch15_network.network.News

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


//복사해서 작성................
class MyNewsViewHolder(val binding: ItemNewsBinding): RecyclerView.ViewHolder(binding.root)

class MyNewsAdapter(val context: Context, val datas: MutableList<News>?): RecyclerView.Adapter<MyNewsViewHolder>(){

    override fun getItemCount(): Int{
        return datas?.size ?: 0
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyNewsViewHolder
            = MyNewsViewHolder(ItemNewsBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: MyNewsViewHolder, position: Int) {
                //add......................................
        val news=datas!![position]
        holder.binding.run {
            itemTitle.text=news.title
            itemDesc.text=news.description
            itemTime.text="${news.author} At ${news.publishedAt}"
            news.urlToImage?.let {
                val avatarImageCall = MyApplication.networkService.getNetworkImage(news.urlToImage!!)
                avatarImageCall.enqueue(object : Callback<ResponseBody> {
                    override fun onResponse(call: Call<ResponseBody>, response: Response<ResponseBody>) {
                        if (response.isSuccessful) {
                            if (response.body() != null) {
                                val bitmap = BitmapFactory.decodeStream(response.body()!!.byteStream())
                                itemImage.setImageBitmap(bitmap)
                            }
                        }
                    }

                    override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                        call.cancel()
                    }
                })
            }
        }



    }
}