package com.example.ch15_network.util

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import android.widget.ImageView

fun uriToImageView(context: Context, uri: Uri, imageView: ImageView): Boolean{

    Log.d("kkang", "${uri.toString()}")
    val option = BitmapFactory.Options()
    option.inSampleSize = 10

    var inputStream = context.contentResolver.openInputStream(uri)
    val bitmap = BitmapFactory.decodeStream(inputStream, null, option)
    inputStream!!.close()
    bitmap?.let {
        imageView.setImageBitmap(bitmap)
        return true

    }
    return false
}

fun fileToImageView(context: Context, filePath: String, imageView: ImageView): Boolean{
    val option = BitmapFactory.Options()
    option.inSampleSize = 10

    val bitmap = BitmapFactory.decodeFile(filePath, option)
    bitmap?.let {
        imageView.setImageBitmap(bitmap)
        return true

    }
    return false
}