package com.example.ch15_network

import android.app.Service
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Intent
import android.os.IBinder
import android.util.Log

class MyJobService : JobService() {
    override fun onStartJob(jobParameters: JobParameters): Boolean {
        Log.d("kkang", "onStartJob.....................")

        return false
    }
    override fun onStopJob(jobParameters: JobParameters): Boolean {
        return true
    }
}