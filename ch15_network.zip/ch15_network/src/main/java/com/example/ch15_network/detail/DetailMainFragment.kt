package com.example.ch15_network.detail

import android.content.Context
import android.graphics.Rect
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ch15_network.R
import com.example.ch15_network.databinding.FragmentDetailMainBinding
import com.example.ch15_network.databinding.ItemRecyclerviewBinding


class MyViewHolder(val binding: ItemRecyclerviewBinding) :
    RecyclerView.ViewHolder(binding.root)

class MyAdapter(val datas: MutableList<Product>) :
    RecyclerView.Adapter<MyViewHolder>() {

    override fun getItemCount(): Int {
        return datas.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
            MyViewHolder {
        return MyViewHolder(
            ItemRecyclerviewBinding.inflate(LayoutInflater.from(
            parent.context), parent, false))
    }


    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {

        val product = datas.get(position)
        holder.binding.run {
            itemTitleView.text = product.title
            itemDescView.text = product.desc
            itemImageView.setImageResource(product.photo)
        }
    }
}

class MyDecoration(val context: Context): RecyclerView.ItemDecoration() {


    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)
        val index = parent.getChildAdapterPosition(view) + 1
        if (index % 3 == 0) // left, top, right, bottom
            outRect.set(10, 10, 10, 60)
        else
            outRect.set(10, 10, 10, 0)

    }
}

class Product(val photo: Int, val title: String, val desc: String)

val datas = mutableListOf<Product>(
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
    Product(R.drawable.item1, "스위스/이탈리아 9일", "터키항공 잔여석31 가이드동행"),
    Product(R.drawable.item2, "서유럽 4국 9일", "아시아나항공 잔여석25 가이드동행"),
    Product(R.drawable.item3, "스위스 일주 9일", "대한항공 잔여석19 가이드동행"),
)

class DetailMainFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val binding = FragmentDetailMainBinding.inflate(inflater, container, false)

        val layoutManager = LinearLayoutManager(activity)
        binding.recyclerView.layoutManager=layoutManager
        val adapter= MyAdapter(datas)
        binding.recyclerView.adapter=adapter
        binding.recyclerView.addItemDecoration(MyDecoration(activity as Context))
        return binding.root
    }
}