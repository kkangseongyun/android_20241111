package com.example.ch15_network

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ch15_network.databinding.ActivityMyInfoBinding
import com.example.ch15_network.db.insertInfo
import com.example.ch15_network.db.selectInfo
import com.example.ch15_network.util.fileToImageView
import com.example.ch15_network.util.uriToImageView
import java.io.BufferedReader
import java.io.File
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.Date

class MyInfoActivity : AppCompatActivity() {

    lateinit var binding: ActivityMyInfoBinding

    var email: String? = null
    var phone: String? = null
    var photo: String? = null

    lateinit var cameraFilePath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMyInfoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setSupportActionBar(binding.toolbar)

        val cursor = selectInfo(this)
        cursor?.let {
            if(cursor.moveToFirst()){
                binding.run {
                    email = cursor.getString(1)
                    phone = cursor.getString(2)
                    photo = cursor.getString(3)
                    myInfoEmail.setText(email)
                    myInfoPhone.setText(phone)

                    if(photo?.isNotEmpty() == true ?: false){
                        fileToImageView(this@MyInfoActivity, photo!!, userImageView)
                    }
                }
            }
        }


        binding.myInfoInternalButton.setOnClickListener {
            val file = File(filesDir, "test.txt")
            val writeStream: OutputStreamWriter = file.writer()
            writeStream.write("hello world - internal")
            writeStream.flush()

            val readStream: BufferedReader = file.reader().buffered()
            readStream.forEachLine {
                binding.myInfoInternalResult.text = it
            }
        }
        binding.myInfoExternalButton.setOnClickListener {

            val file: File = File(getExternalFilesDir(null), "test.txt")
            val writeStream: OutputStreamWriter = file.writer()
            writeStream.write("hello world - external")
            writeStream.flush()

            val readStream: BufferedReader = file.reader().buffered()
            readStream.forEachLine {
                binding.myInfoExternalResult.text = it
            }
        }

        val requestGalleryLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult())
        {
            try {

                val uri = it.data!!.data!!
                //uri 를 저장해서 이후에 다시 사용하는 것은 금지되어 있다.
                val proj = arrayOf(MediaStore.Images.Media.DATA)
                val cursor = contentResolver.query(
                    uri,
                    proj,
                    null,
                    null,
                    null
                )
                cursor?.let {
                    if(cursor.moveToFirst()){
                        photo = cursor.getString(0)
                    }

                }
                //stream 을 직접 제공하는 것 테스트를 위해서...
                uriToImageView(this, uri, binding.userImageView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) {
            if (it) {
                val intent = Intent(
                    Intent.ACTION_PICK,
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                intent.type = "image/*"
                requestGalleryLauncher.launch(intent)
            } else {
                Toast.makeText(this, "permission denied...", Toast.LENGTH_SHORT).show()
            }
        }

        binding.galleryButton.setOnClickListener {

            if(Build.VERSION.SDK_INT >= 33) {
                if (ContextCompat.checkSelfPermission(this, "android.permission.READ_MEDIA_IMAGES") == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(
                        Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                    intent.type = "image/*"
                    requestGalleryLauncher.launch(intent)
                } else {
                    permissionLauncher.launch("android.permission.READ_MEDIA_IMAGES")
                }

            }else {
                if (ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE") == PackageManager.PERMISSION_GRANTED) {
                    val intent = Intent(
                        Intent.ACTION_PICK,
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
                    intent.type = "image/*"
                    requestGalleryLauncher.launch(intent)
                } else {
                    permissionLauncher.launch("android.permission.READ_EXTERNAL_STORAGE")
                }
            }

        }

        val requestCameraFileLauncher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult())
        {
            // 카메라 앱
            fileToImageView(this, cameraFilePath, binding.userImageView)
            photo = cameraFilePath

        }
        binding.cameraButton.setOnClickListener {

            val timeStamp: String =
                SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
            val storageDir: File? =
                getExternalFilesDir(Environment.DIRECTORY_PICTURES)
            val file = File.createTempFile(
                "JPEG_${timeStamp}_",
                ".jpg",
                storageDir
            )
            cameraFilePath = file.absolutePath
            val photoURI: Uri = FileProvider.getUriForFile(
                this,
                "com.example.ch13_provider.fileprovider", file
            )
            val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            intent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
            requestCameraFileLauncher.launch(intent)

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_my_info, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == R.id.menu_my_info_save){
            binding.run {
                email = myInfoEmail.text.toString()
                phone = myInfoPhone.text.toString()
            }
            if(email?.isNotEmpty() ?: false){
                if(insertInfo(this, email ?: "", phone, photo)){
                    intent.putExtra("phone", phone)
                    intent.putExtra("email", email)
                    intent.putExtra("photo", photo)
                    setResult(RESULT_OK, intent)
                    finish()
                }
            }else {
                Toast.makeText(this, "email 은 필수 입력입니다.", Toast.LENGTH_SHORT).show()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}