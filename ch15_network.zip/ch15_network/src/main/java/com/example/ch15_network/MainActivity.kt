package com.example.ch15_network

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.ch15_network.databinding.ActivityMainBinding
import com.example.ch15_network.databinding.NavigationHeaderBinding
import com.example.ch15_network.db.selectInfo
import com.example.ch15_network.util.fileToImageView

class MainActivity : AppCompatActivity() {

    var initTime = 0L

    lateinit var toggle: ActionBarDrawerToggle
    lateinit var headerBinding: NavigationHeaderBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        headerBinding = NavigationHeaderBinding.bind(binding.mainDrawerView.getHeaderView(0))


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        binding.mainEvent1.setOnClickListener {
            val intent = Intent(this, DetailActivity::class.java)
            startActivity(intent)
        }

        setSupportActionBar(binding.toolbar)

        toggle = ActionBarDrawerToggle(this, binding.main, R.string.drawer_opened,
            R.string.drawer_closed)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toggle.syncState()

        val launcher = registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ){


            val email = it.data?.getStringExtra("email")
            val photo = it.data?.getStringExtra("photo")

            email?.let {
                headerBinding.userEmailView.text = email
            }
            photo?.let {
                fileToImageView(this@MainActivity, photo, headerBinding.userImageView)
            }

        }

        val permissionLauncher = registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {
            if (it.all { permission -> permission.value == true }) {
                noti()
            } else {
                Toast.makeText(this, "permission denied...", Toast.LENGTH_SHORT).show()
            }
        }

        binding.mainDrawerView.setNavigationItemSelectedListener {
            if(it.itemId == R.id.main_navigation_about){
                val intent = Intent(this, AboutActivity::class.java)
                startActivity(intent)
            }else if(it.itemId == R.id.main_navigation_edit_info){
                val intent = Intent(this, MyInfoActivity::class.java)
                launcher.launch(intent)
            }
            else if(it.itemId == R.id.main_navigation_notification){
                if(Build.VERSION.SDK_INT >= 33) {
                    if (ContextCompat.checkSelfPermission(
                            this,
                            "android.permission.POST_NOTIFICATIONS"
                        ) == PackageManager.PERMISSION_GRANTED
                    ) {
                        noti()
                    } else {
                        permissionLauncher.launch(
                            arrayOf(
                                "android.permission.POST_NOTIFICATIONS"
                            )
                        )
                    }
                }else {
                    noti()
                }
            }
            else if(it.itemId == R.id.main_navigation_schedular){
                var jobScheduler: JobScheduler? = getSystemService(JOB_SCHEDULER_SERVICE) as JobScheduler
                val builder = JobInfo.Builder(1, ComponentName(this, MyJobService::class.java))
                builder.setRequiredNetworkType(JobInfo.NETWORK_TYPE_UNMETERED)
                val jobInfo = builder.build()
                jobScheduler!!.schedule(jobInfo)
            }

            true
        }
        val cursor = selectInfo(this)
        cursor?.let {
            if(cursor.moveToFirst()){

                headerBinding.run {
                    userEmailView.setText(cursor.getString(1))

                    val photo = cursor.getString(3)

                    if(photo?.isNotEmpty() ?: false) {
                        fileToImageView(this@MainActivity, photo, userImageView)
                    }
                }
            }
        }



    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode === KeyEvent.KEYCODE_BACK) {
            if (System.currentTimeMillis() - initTime > 3000) {
                Toast.makeText(this, "종료하려면 한 번 더 누르세요!!",
                    Toast.LENGTH_SHORT).show()
                initTime = System.currentTimeMillis()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)

        val menuItem = menu?.findItem(R.id.menu_search)
        val searchView = menuItem?.actionView as SearchView

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextChange(newText: String?): Boolean {
                return true
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                //키보드에서 검색 버튼을 누르는 순간의 이벤트
                Toast.makeText(this@MainActivity,"$query", Toast.LENGTH_SHORT).show()
                searchView.setQuery("", false)
                searchView.isIconified = true
                return true
            }
        })

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(toggle.onOptionsItemSelected(item)){
            return true
        }else
            if(item.itemId == R.id.menu_setting){
            val intent = Intent(this, SettingActivity::class.java)
            startActivity(intent)
        }
        return super.onOptionsItemSelected(item)
    }

    fun noti() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val builder: NotificationCompat.Builder

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channelId = "one-channel"
            val channelName = "My Channel One"
            val channel = NotificationChannel(
                channelId,
                channelName,
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "My Channel One Description"

            manager.createNotificationChannel(channel)

            builder = NotificationCompat.Builder(this, channelId)
        } else {
            builder = NotificationCompat.Builder(this)
        }

        builder.setSmallIcon(android.R.drawable.ic_notification_overlay)
        builder.setWhen(System.currentTimeMillis())
        builder.setContentTitle("Content Title")
        builder.setContentText("Content Massage")

        val intent = Intent(this, MyReceiver::class.java)
        intent.putExtra("data", "hello")
        val pendingIntent =
            PendingIntent.getBroadcast(
                this, 10, intent,
                PendingIntent.FLAG_IMMUTABLE
            )
        builder.setContentIntent(pendingIntent)
        builder.setAutoCancel(true)



        manager.notify(11, builder.build())
    }
}